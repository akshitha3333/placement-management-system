import { useState, useEffect } from "react";
import axios from "axios";
import Cookies from "js-cookie";
const rest = require("../../../Rest");

const getHeaders = () => {
  const token = Cookies.get("token") || localStorage.getItem("token") || "";
  return { headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` } };
};

const FEEDBACK_URL = "http://localhost:2026/api/interactions/feedback";
const baseApi           = () => rest.jobApplications.replace(/\/job-applications.*$/, "");
const interviewByAppUrl = (appId) => `${baseApi()}/job-application/${appId}/interview`;

// ── Pull student from every known nesting path ────────────────────────────────
const extractStudent = (inv) => {
  const candidates = [
    inv?.jobApplicationModel?.resumeModel?.studentModel,
    inv?.jobApplicationModel?.jobSuggestionModel?.studentModel,
    inv?.jobApplicationModel?.studentModel,
    inv?._appFallback?.resumeModel?.studentModel,
    inv?._appFallback?.jobSuggestionModel?.studentModel,
  ];
  for (const c of candidates) {
    if (c && (c.studentId || c.id)) return c;
  }
  return null;
};

const RATING_OPTIONS = ["Excellent", "Good", "Average", "Needs Improvement"];

const ratingMeta = (r) =>
  ({
    Excellent:           { bg: "rgba(22,163,74,0.1)",  color: "#16a34a" },
    Good:                { bg: "rgba(14,165,233,0.1)", color: "#0ea5e9" },
    Average:             { bg: "rgba(245,158,11,0.1)", color: "#f59e0b" },
    "Needs Improvement": { bg: "rgba(220,38,38,0.1)",  color: "#dc2626" },
  }[r] || { bg: "rgba(107,114,128,0.1)", color: "#6b7280" });

// Feedback string format: "[Rating]||sName:X||tName:Y||text:Z"
const SEP = "||";
const buildFeedbackStr = (rating, text, studentName, tutorName) =>
  `[${rating}]${SEP}sName:${studentName}${SEP}tName:${tutorName}${SEP}text:${text}`;

const parseFeedback = (fb) => {
  const raw = fb.feedback || "";
  if (raw.includes(`${SEP}sName:`)) {
    const rating      = (raw.match(/^\[(.+?)\]/) || [])[1] || "Good";
    const studentName = (raw.match(/\|\|sName:(.+?)\|\|/) || [])[1] || "—";
    const tutorName   = (raw.match(/\|\|tName:(.+?)\|\|/) || [])[1] || "—";
    const text        = (raw.match(/\|\|text:(.+)$/s) || [])[1] || "";
    return { rating, studentName, tutorName, text };
  }
  // Legacy fallback
  const rating = (raw.match(/^\[(.+?)\]/) || [])[1] || "Good";
  const text   = raw.replace(/^\[.+?\]\s*/, "");
  return { rating, studentName: "—", tutorName: "—", text };
};

const emptyForm = { studentId: "", tutorId: "", rating: "Good", feedbackText: "" };

// ─────────────────────────────────────────────────────────────────────────────
function CompanyFeedback() {
  const [interviews,   setInterviews]   = useState([]);
  const [tutors,       setTutors]       = useState([]);   // all tutors from API
  const [feedbacks,    setFeedbacks]    = useState([]);
  const [loading,      setLoading]      = useState(true);
  const [submitting,   setSubmitting]   = useState(false);
  const [showModal,    setShowModal]    = useState(false);
  const [form,         setForm]         = useState(emptyForm);
  const [message,      setMessage]      = useState({ text: "", type: "" });
  const [filterRating, setFilterRating] = useState("");

  // ── Init ──────────────────────────────────────────────────────────────────
  useEffect(() => {
    const init = async () => {
      setLoading(true);
      try {
        // 1. Fetch tutors list + job applications in parallel
        const [tutorRes, appsRes] = await Promise.all([
          axios.get(rest.tutor,           getHeaders()),
          axios.get(rest.jobApplications, getHeaders()),
        ]);

        // Tutors
        const tutorList = tutorRes.data?.data || tutorRes.data || [];
        setTutors(Array.isArray(tutorList) ? tutorList : []);

        // Applications → interviews
        const apps = Array.isArray(appsRes.data?.data)
          ? appsRes.data.data
          : Array.isArray(appsRes.data) ? appsRes.data : [];

        const invArrays = await Promise.all(
          apps.map(async (app) => {
            const appId = app.jobApplicationId || app.id;
            try {
              const res  = await axios.get(interviewByAppUrl(appId), getHeaders());
              const data = res.data?.data || res.data;
              const list = Array.isArray(data) ? data : data ? [data] : [];
              return list.map((i) => ({ ...i, _appFallback: app }));
            } catch { return []; }
          })
        );
        setInterviews(invArrays.flat().filter(Boolean));

        // 2. Past feedbacks this company sent
        try {
          const fbRes  = await axios.get(FEEDBACK_URL, getHeaders());
          const fbList = fbRes.data?.data || fbRes.data || [];
          setFeedbacks(
            (Array.isArray(fbList) ? fbList : []).filter(
              (f) => f.feedback_by_role === "COMPANY" && f.feedback_to_role === "TUTOR"
            )
          );
        } catch { /* non-fatal */ }
      } catch (err) {
        console.error("CompanyFeedback init:", err);
      } finally {
        setLoading(false);
      }
    };
    init();
  }, []);

  // ── Unique students from interviews ───────────────────────────────────────
  const studentOptions = (() => {
    const seen = new Set();
    return interviews.reduce((acc, inv) => {
      const stu = extractStudent(inv);
      if (!stu) return acc;
      const sid = String(stu.studentId || stu.id);
      if (seen.has(sid)) return acc;
      seen.add(sid);
      acc.push({
        studentId:   sid,
        studentName: stu.name || stu.studentName || `Student #${sid}`,
      });
      return acc;
    }, []);
  })();

  // Selected student name (for embedding in feedback string)
  const selectedStudentName =
    studentOptions.find((s) => s.studentId === form.studentId)?.studentName || "—";

  // Selected tutor name (for embedding in feedback string)
  const selectedTutorName =
    tutors.find((t) => String(t.tutorId || t.id) === form.tutorId)?.tutorName || "—";

  // ── Submit ────────────────────────────────────────────────────────────────
  const handleSubmit = async () => {
    if (!form.studentId) {
      setMessage({ text: "Please select a student.", type: "error" }); return;
    }
    if (!form.tutorId) {
      setMessage({ text: "Please select a tutor.", type: "error" }); return;
    }
    if (!form.feedbackText.trim()) {
      setMessage({ text: "Please enter feedback.", type: "error" }); return;
    }

    setSubmitting(true);
    setMessage({ text: "", type: "" });

    // Embed names into the feedback string → survives DB round-trip
    const feedbackString = buildFeedbackStr(
      form.rating,
      form.feedbackText,
      selectedStudentName,
      selectedTutorName
    );

    // CRITICAL: Java field is `feedbackTo` (Long) → JSON key must be "feedbackTo"
    // Jackson maps camelCase → snake_case column automatically
    const payload = {
      feedback:         feedbackString,
      feedbackTo:       Number(form.tutorId),
      feedback_by_role: "COMPANY",
      feedback_to_role: "TUTOR",
    };

    console.log("CompanyFeedback — POST payload:", payload);

    try {
      const res = await axios.post(FEEDBACK_URL, payload, getHeaders());
      if (res.data?.success !== false) {
        // Re-fetch to get persisted records with real feedbackId
        const fbRes  = await axios.get(FEEDBACK_URL, getHeaders());
        const fbList = fbRes.data?.data || fbRes.data || [];
        setFeedbacks(
          (Array.isArray(fbList) ? fbList : []).filter(
            (f) => f.feedback_by_role === "COMPANY" && f.feedback_to_role === "TUTOR"
          )
        );
        setShowModal(false);
        setForm(emptyForm);
        setMessage({ text: "Feedback submitted successfully!", type: "success" });
        setTimeout(() => setMessage({ text: "", type: "" }), 3500);
      } else {
        throw new Error(res.data?.message || "Submission failed");
      }
    } catch (err) {
      console.error("CompanyFeedback submit error:", err.response?.data || err);
      setMessage({
        text: err.response?.data?.message || err.message || "Failed to submit feedback.",
        type: "error",
      });
    } finally {
      setSubmitting(false);
    }
  };

  const filtered    = feedbacks.filter((f) => !filterRating || parseFeedback(f).rating === filterRating);
  const countRating = (label) => feedbacks.filter((f) => parseFeedback(f).rating === label).length;

  // ─────────────────────────────────────────────────────────────────────────
  return (
    <div className="p-4">

      {/* ── Header ── */}
      <div className="row space-between items-center mb-4">
        <div>
          <h2 className="fs-5 bold">Company Feedback</h2>
          <p className="fs-p9 text-secondary">Send performance feedback about students to their tutors</p>
        </div>
        <button
          className="btn btn-primary w-auto"
          style={{ padding: "10px 20px" }}
          onClick={() => { setShowModal(true); setMessage({ text: "", type: "" }); }}
        >
          + Give Feedback
        </button>
      </div>

      {/* ── Flash message ── */}
      {message.text && !showModal && (
        <div className="p-3 mb-3 fs-p9" style={{
          background:   message.type === "success" ? "rgba(22,163,74,0.1)"  : "rgba(220,38,38,0.1)",
          border:       `1px solid ${message.type === "success" ? "rgba(22,163,74,0.3)" : "rgba(220,38,38,0.3)"}`,
          color:        message.type === "success" ? "#16a34a" : "#dc2626",
          borderRadius: "8px",
        }}>
          {message.text}
        </div>
      )}

      {/* ── Stat cards ── */}
      <div className="row mb-4" style={{ gap: "12px" }}>
        {[
          { label: "Total Sent",        value: feedbacks.length,               color: "#325563" },
          { label: "Excellent",         value: countRating("Excellent"),        color: "#16a34a" },
          { label: "Good",              value: countRating("Good"),             color: "#0ea5e9" },
          { label: "Needs Improvement", value: countRating("Needs Improvement"),color: "#dc2626" },
        ].map((s, i) => (
          <div className="col p-0" key={i}>
            <div className="card p-3 stat-card text-center">
              <h3 className="bold" style={{ color: s.color, fontSize: "1.8rem" }}>{s.value}</h3>
              <p className="fs-p8 text-secondary mt-1">{s.label}</p>
            </div>
          </div>
        ))}
      </div>

      {/* ── Filter + header ── */}
      <div className="row space-between items-center mb-3">
        <h4 className="bold">📋 Feedback History</h4>
        <div style={{ width: "200px" }}>
          <select className="form-control" value={filterRating}
            onChange={(e) => setFilterRating(e.target.value)}>
            <option value="">All Ratings</option>
            {RATING_OPTIONS.map((r) => <option key={r} value={r}>{r}</option>)}
          </select>
        </div>
      </div>

      {/* ── Feedback list ── */}
      {loading ? (
        <div className="card p-5 text-center">
          <p className="text-secondary fs-p9">Loading...</p>
        </div>
      ) : feedbacks.length === 0 ? (
        <div className="card p-5 text-center">
          <p style={{ fontSize: "3rem" }}>📝</p>
          <p className="bold mt-2">No feedback submitted yet</p>
          <p className="text-secondary fs-p9 mt-1">
            Click "+ Give Feedback" to send feedback to a student's tutor
          </p>
        </div>
      ) : filtered.length === 0 ? (
        <div className="card p-4 text-center">
          <p className="text-secondary">No feedback matches the selected filter</p>
        </div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
          {filtered.map((fb, i) => {
            const { rating, studentName, tutorName, text } = parseFeedback(fb);
            const { bg, color } = ratingMeta(rating);
            return (
              <div key={fb.feedbackId || i} className="card p-4"
                style={{ borderLeft: `4px solid ${color}` }}>
                <div className="row space-between items-center mb-2">
                  <div>
                    <span className="bold fs-p9">🎓 {studentName}</span>
                    <span className="fs-p8 text-secondary ms-2">
                      → Tutor: <strong>{tutorName}</strong>
                    </span>
                  </div>
                  <span style={{
                    background: bg, color, fontWeight: 600,
                    padding: "3px 10px", borderRadius: "20px", fontSize: "0.75rem",
                  }}>
                    {rating}
                  </span>
                </div>
                <p className="fs-p9" style={{ color: "#374151", lineHeight: "1.5" }}>{text}</p>
              </div>
            );
          })}
        </div>
      )}

      {/* ── Modal ── */}
      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="card p-5" style={{ width: "520px", maxWidth: "95%" }}
            onClick={(e) => e.stopPropagation()}>

            <div className="row space-between items-center mb-4">
              <h3 className="bold">📝 Give Feedback</h3>
              <span className="cursor-pointer fs-4 text-secondary"
                onClick={() => setShowModal(false)}>✕</span>
            </div>

            {/* ── Step 1: Select Student ── */}
            <div className="form-group mb-3">
              <label className="form-control-label">Student *</label>
              {studentOptions.length === 0 ? (
                <div className="p-3 fs-p9" style={{
                  background: "rgba(245,158,11,0.08)",
                  border: "1px solid rgba(245,158,11,0.3)",
                  color: "#f59e0b", borderRadius: "8px",
                }}>
                  ⚠️ No interviewed students found. Students appear once interviews are scheduled.
                </div>
              ) : (
                <select className="form-control" value={form.studentId}
                  onChange={(e) => setForm({ ...form, studentId: e.target.value, tutorId: "" })}>
                  <option value="">-- Select a student --</option>
                  {studentOptions.map((s) => (
                    <option key={s.studentId} value={s.studentId}>{s.studentName}</option>
                  ))}
                </select>
              )}
            </div>

            {/* ── Step 2: Select Tutor ── */}
            <div className="form-group mb-3">
              <label className="form-control-label">Tutor *</label>
              <select className="form-control" value={form.tutorId}
                onChange={(e) => setForm({ ...form, tutorId: e.target.value })}
                disabled={tutors.length === 0}>
                <option value="">-- Select the student's tutor --</option>
                {tutors.map((t) => (
                  <option key={t.tutorId || t.id} value={String(t.tutorId || t.id)}>
                    {t.tutorName || t.name || `Tutor #${t.tutorId || t.id}`}
                  </option>
                ))}
              </select>
            </div>

            {/* ── Confirmation banner ── */}
            {form.studentId && form.tutorId && (
              <div className="mb-3 p-3" style={{
                background: "rgba(22,163,74,0.08)",
                border: "1px solid rgba(22,163,74,0.25)",
                borderRadius: "8px",
              }}>
                <p className="fs-p8" style={{ color: "#16a34a" }}>
                  ✅ Sending feedback for{" "}
                  <strong>{selectedStudentName}</strong>{" "}
                  to tutor{" "}
                  <strong>{selectedTutorName}</strong>
                </p>
              </div>
            )}

            {/* ── Rating ── */}
            <div className="form-group mb-3">
              <label className="form-control-label">Rating</label>
              <select className="form-control" value={form.rating}
                onChange={(e) => setForm({ ...form, rating: e.target.value })}>
                {RATING_OPTIONS.map((r) => <option key={r}>{r}</option>)}
              </select>
            </div>

            {/* ── Feedback text ── */}
            <div className="form-group mb-4">
              <label className="form-control-label">Feedback *</label>
              <textarea className="form-control" rows="4"
                placeholder="Describe the student's performance, attitude, skills, etc..."
                value={form.feedbackText}
                onChange={(e) => setForm({ ...form, feedbackText: e.target.value })} />
            </div>

            {/* Modal error */}
            {message.text && showModal && (
              <div className="fs-p9 mb-3 p-2" style={{
                color: "#dc2626", background: "rgba(220,38,38,0.08)",
                border: "1px solid rgba(220,38,38,0.2)", borderRadius: "6px",
              }}>
                {message.text}
              </div>
            )}

            <div className="row" style={{ gap: "10px" }}>
              <button className="btn btn-primary" onClick={handleSubmit}
                disabled={submitting || !form.studentId || !form.tutorId || !form.feedbackText.trim()}>
                {submitting ? "Submitting..." : "📤 Submit Feedback"}
              </button>
              <button className="btn btn-muted"
                onClick={() => { setShowModal(false); setMessage({ text: "", type: "" }); }}>
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default CompanyFeedback;