import { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import Cookies from 'js-cookie';
const rest = require("../../Rest")

function AdminLogin() {
     const [emailError, setEmailError] = useState("");
     const [passwordError, setPasswordError] = useState("");
     const [message, setMessage] = useState("");
     const [msgType, setMsgType] = useState("");
     const navigate = useNavigate();

     const validateEmail= (e)=>{
        const email= e.target.value;
        const emailPattern=/^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if(email ===""){
            setEmailError("Email is required");
        }else if(!emailPattern.test(email)){
            setEmailError("Invalid Email Format");   
        }else{
            setEmailError("");
        }
    }
    const validatePassword = (e) => {
    const password = e.target.value;
    if(password === ""){
        setPasswordError("Password is required");
    }
    else{
        setPasswordError("");
    }
}
let header = {
        headers: {
            "Content-type": "Application/json"
        }
    }
    const AdminLogin = (e) => {
        e.preventDefault();
        let email = document.getElementById("Email").value;
        let password=document.getElementById("Password").value;
        let data = {
            "email": email,
            "password": password,
        }
        console.log(rest.login);
        
        axios.post(rest.login, data, header)
            .then(response => {
                const result = response.data
                console.log(result);
                if (response.data.success){
                    Cookies.set("token", response.data.data);
                    setMessage("Login successful! Redirecting...");
                    setMsgType("success");
                    setTimeout(() => navigate("/admin-page"), 1500);
                }else{
                    setMessage(response.data.message || "Invalid credentials. Please try again.");
                    setMsgType("error");
                }
            })
            .catch(error => {
                console.log(error);
                setMessage(error.response?.data?.message || "Something went wrong. Please try again.");
                setMsgType("error");
            });
    }
     
    return (
            <div className="card w-30 m-auto p-5">
                <div className="text-center">
                    <svg xmlns="http://www.w3.org/2000/svg" width="55" height="55" fill="currentColor" className="bi bi-shield-check" viewBox="0 0 16 16">
                      <path d="M5.338 1.59a61 61 0 0 0-2.837.856.48.48 0 0 0-.328.39c-.554 4.157.726 7.19 2.253 9.188a10.7 10.7 0 0 0 2.287 2.233c.346.244.652.42.893.533q.18.085.293.118a1 1 0 0 0 .101.025 1 1 0 0 0 .1-.025q.114-.034.294-.118c.24-.113.547-.29.893-.533a10.7 10.7 0 0 0 2.287-2.233c1.527-1.997 2.807-5.031 2.253-9.188a.48.48 0 0 0-.328-.39c-.651-.213-1.75-.56-2.837-.855C9.552 1.29 8.531 1.067 8 1.067c-.53 0-1.552.223-2.662.524zM5.072.56C6.157.265 7.31 0 8 0s1.843.265 2.928.56c1.11.3 2.229.655 2.887.87a1.54 1.54 0 0 1 1.044 1.262c.596 4.477-.787 7.795-2.465 9.99a11.8 11.8 0 0 1-2.517 2.453 7 7 0 0 1-1.048.625c-.28.132-.581.24-.829.24s-.548-.108-.829-.24a7 7 0 0 1-1.048-.625 11.8 11.8 0 0 1-2.517-2.453C1.928 10.487.545 7.169 1.141 2.692A1.54 1.54 0 0 1 2.185 1.43 63 63 0 0 1 5.072.56"/>
                      <path d="M10.854 5.146a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708 0l-1.5-1.5a.5.5 0 1 1 .708-.708L7.5 7.793l2.646-2.647a.5.5 0 0 1 .708 0"/>
                    </svg>
                     <h2 className="mt-2">Admin Login</h2>
                     <p className="mt-2">Access the administration Portal</p>

                    {message && (
                        <div className={msgType === "success" ? "alert-success mt-3" : "alert-danger mt-3"}>
                            <p className={msgType === "success" ? "text-success" : "text-danger"}>
                                {message}
                            </p>
                        </div>
                    )}

                </div>
               <form onSubmit={AdminLogin} method="post">
                <div className="form-group mt-5">
                    <label className="form-control-label" htmlFor="Email">Email Address</label>
                    <input  className="form-control" type="email" name="Email" id="Email" placeholder="Enter your email" required onKeyUp={validateEmail}/>
                    {emailError && <p className="text-danger fs-p8 mt-1">{emailError}</p>}
                </div>
                 <div className="form-group mt-5">
                    <label className="form-control-label" htmlFor="Password">Password</label>
                    <input  className="form-control" type="password" name="password" id="Password" placeholder="Enter your Password" required onKeyUp={validatePassword}/>
                    {passwordError && <p className="text-danger fs-p8 mt-1">{passwordError}</p>}
                </div>
                <div>
                    <input  className="btn btn-primary mt-5" type="submit" name="Login" value="Login" />
                </div>
                <div className="fs-p7 text-center text-link mt-2" >
                    <a href="/roleselection">Back to role Selection</a>
                </div>
               </form>
                
            </div>
    )
}
export default AdminLogin;