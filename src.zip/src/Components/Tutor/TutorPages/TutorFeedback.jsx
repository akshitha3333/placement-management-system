import { useState, useEffect } from "react";
import axios from "axios";
import Cookies from "js-cookie";
const rest = require("../../../Rest");

const FEEDBACK_URL = "http://localhost:2026/api/interactions/feedback";

const getHeaders = () => {
  const token = Cookies.get("token") || localStorage.getItem("token") || "";
  return { headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` } };
};

const ratingMeta = (r) =>
  ({
    Excellent:           { bg: "rgba(22,163,74,0.1)",  color: "#16a34a" },
    Good:                { bg: "rgba(14,165,233,0.1)", color: "#0ea5e9" },
    Average:             { bg: "rgba(245,158,11,0.1)", color: "#f59e0b" },
    "Needs Improvement": { bg: "rgba(220,38,38,0.1)",  color: "#dc2626" },
  }[r] || { bg: "rgba(107,114,128,0.1)", color: "#6b7280" });

// Parse feedback string company embedded
// Format: "[Rating]||sName:StudentName||tName:TutorName||text:actual feedback"
const SEP = "||";
const parseFeedback = (fb) => {
  const raw = fb.feedback || "";
  if (raw.includes(`${SEP}sName:`)) {
    const rating      = (raw.match(/^\[(.+?)\]/) || [])[1] || "Good";
    const studentName = (raw.match(/\|\|sName:(.+?)\|\|/) || [])[1] || "—";
    const tutorName   = (raw.match(/\|\|tName:(.+?)\|\|/) || [])[1] || "—";
    const text        = (raw.match(/\|\|text:(.+)$/s) || [])[1] || "";
    return { rating, studentName, tutorName, text };
  }
  // Legacy plain format
  const rating = (raw.match(/^\[(.+?)\]/) || [])[1] || "Good";
  const text   = raw.replace(/^\[.+?\]\s*/, "");
  return { rating, studentName: "—", tutorName: "—", text };
};

// ─────────────────────────────────────────────────────────────────────────────
function TutorFeedback() {
  const [feedbacks,     setFeedbacks]     = useState([]);
  const [students,      setStudents]      = useState([]);
  const [loading,       setLoading]       = useState(true);
  const [error,         setError]         = useState("");
  const [filterStudent, setFilterStudent] = useState("");
  const [filterRating,  setFilterRating]  = useState("");

  useEffect(() => {
    const init = async () => {
      try {
        // 1. Tutor profile + dept students
        const [tutorRes, stuRes] = await Promise.all([
          axios.get(rest.tutor,    getHeaders()),
          axios.get(rest.students, getHeaders()),
        ]);

        const tutorList   = tutorRes.data?.data || tutorRes.data || [];
        const tutor       = Array.isArray(tutorList) ? tutorList[0] : tutorList;
        const tutorDeptId = tutor?.departmentModel?.departmentId || tutor?.departmentId;

        const allStudents = stuRes.data?.data || stuRes.data || [];
        const stuList     = Array.isArray(allStudents) ? allStudents : [];
        const myStudents  = tutorDeptId
          ? stuList.filter((s) => {
              const sd = s?.departmentModel?.departmentId || s?.departmentId;
              return String(sd) === String(tutorDeptId);
            })
          : stuList;
        setStudents(myStudents);

        // 2. GET /api/interactions/feedback
        //    With backend fix (InteractionService TUTOR → findByFeedbackTo),
        //    this returns feedbacks sent TO this tutor by companies.
        const fbRes  = await axios.get(FEEDBACK_URL, getHeaders());
        const fbList = fbRes.data?.data || fbRes.data || [];
        const all    = Array.isArray(fbList) ? fbList : [];
        console.log("TutorFeedback — raw feedbacks from API:", all);

        // Only COMPANY→TUTOR feedbacks
        const incoming = all.filter(
          (f) => f.feedback_by_role === "COMPANY" && f.feedback_to_role === "TUTOR"
        );
        setFeedbacks(incoming);
      } catch (err) {
        console.error("TutorFeedback init:", err);
        setError("Failed to load feedback. Please refresh.");
      } finally {
        setLoading(false);
      }
    };
    init();
  }, []);

  // ── Filter ────────────────────────────────────────────────────────────────
  const filtered = feedbacks.filter((f) => {
    const { rating, studentName } = parseFeedback(f);
    const selectedName = filterStudent
      ? (students.find((s) => String(s.studentId || s.id) === filterStudent)?.name || "")
      : "";
    const matchStudent = !filterStudent
      || studentName.toLowerCase().includes(selectedName.toLowerCase());
    const matchRating = !filterRating || rating === filterRating;
    return matchStudent && matchRating;
  });

  const countRating = (label) =>
    feedbacks.filter((f) => parseFeedback(f).rating === label).length;

  // ─────────────────────────────────────────────────────────────────────────
  return (
    <div className="p-4">

      {/* ── Header ── */}
      <div className="mb-4">
        <h2 className="fs-5 bold">Company Feedback</h2>
        <p className="fs-p9 text-secondary">
          Feedback sent by companies about your students' performance
        </p>
      </div>

      {/* ── Stat cards ── */}
      <div className="row mb-4" style={{ gap: "12px" }}>
        {[
          { label: "Total Received",    value: feedbacks.length,                color: "#325563" },
          { label: "Excellent",         value: countRating("Excellent"),         color: "#16a34a" },
          { label: "Good",              value: countRating("Good"),              color: "#0ea5e9" },
          { label: "Needs Improvement", value: countRating("Needs Improvement"), color: "#dc2626" },
        ].map((s, i) => (
          <div className="col p-0" key={i} style={{ padding: "0 6px" }}>
            <div className="card p-3 stat-card text-center">
              <h3 className="bold" style={{ color: s.color, fontSize: "1.8rem" }}>{s.value}</h3>
              <p className="fs-p9 text-secondary">{s.label}</p>
            </div>
          </div>
        ))}
      </div>

      {/* ── Filters ── */}
      <div className="row space-between items-center mb-3"
        style={{ flexWrap: "wrap", gap: "10px" }}>
        <h4 className="bold">💬 Feedback Records</h4>
        <div className="row items-center" style={{ gap: "10px" }}>
          <div style={{ width: "200px" }}>
            <select className="form-control" value={filterStudent}
              onChange={(e) => setFilterStudent(e.target.value)}>
              <option value="">All Students</option>
              {students.map((s) => (
                <option key={s.studentId || s.id} value={String(s.studentId || s.id)}>
                  {s.name || s.studentName}
                </option>
              ))}
            </select>
          </div>
          <div style={{ width: "190px" }}>
            <select className="form-control" value={filterRating}
              onChange={(e) => setFilterRating(e.target.value)}>
              <option value="">All Ratings</option>
              <option>Excellent</option>
              <option>Good</option>
              <option>Average</option>
              <option>Needs Improvement</option>
            </select>
          </div>
        </div>
      </div>

      {/* ── List ── */}
      {loading ? (
        <div className="card p-5 text-center">
          <p className="text-secondary fs-p9">Loading feedback...</p>
        </div>
      ) : error ? (
        <div className="card p-4" style={{ borderLeft: "4px solid var(--danger)" }}>
          <p style={{ color: "var(--danger)" }}>{error}</p>
        </div>
      ) : feedbacks.length === 0 ? (
        <div className="card p-5 text-center">
          <p style={{ fontSize: "3rem" }}>🏢</p>
          <p className="bold mt-2">No company feedback yet</p>
          <p className="text-secondary fs-p9 mt-1">
            Feedback sent by companies about your students will appear here
          </p>
        </div>
      ) : filtered.length === 0 ? (
        <div className="card p-4 text-center">
          <p className="text-secondary">No feedback matches the selected filters</p>
        </div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: "14px" }}>
          {filtered.map((fb, i) => {
            const { rating, studentName, text } = parseFeedback(fb);
            const { bg, color } = ratingMeta(rating);
            return (
              <div key={fb.feedbackId || i} className="card p-4"
                style={{ borderLeft: `4px solid ${color}` }}>
                <div className="row space-between items-center mb-2">
                  <div>
                    <span className="bold fs-p9">🎓 {studentName}</span>
                    <span className="fs-p8 text-secondary ms-2">
                      • from <strong>Company #{fb.feedbackFrom}</strong>
                    </span>
                  </div>
                  <span style={{
                    background: bg, color, fontWeight: 600,
                    padding: "3px 10px", borderRadius: "20px", fontSize: "0.75rem",
                  }}>
                    {rating}
                  </span>
                </div>
                <p className="fs-p9" style={{ color: "#374151", lineHeight: "1.5" }}>{text}</p>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

export default TutorFeedback;