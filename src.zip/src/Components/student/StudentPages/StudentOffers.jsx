import { useState, useEffect } from "react";
import axios from "axios";
import Cookies from "js-cookie";
const rest = require("../../../Rest");

function StudentOffers() {
  const [offers,         setOffers]         = useState([]);
  const [loading,        setLoading]        = useState(true);
  const [error,          setError]          = useState("");
  const [offerLetterMap, setOfferLetterMap] = useState({});
  const [actionLoading,  setActionLoading]  = useState({});
  const [actionMsg,      setActionMsg]      = useState({});

  const getHeaders = () => ({
    headers: {
      "Content-Type": "application/json",
      Authorization:  `Bearer ${Cookies.get("token") || localStorage.getItem("token") || ""}`,
    },
  });

  const baseApi              = () => rest.jobApplications.replace(/\/job-applications.*$/, "");
  const offerLetterGetUrl    = (id) => `${baseApi()}/interview-schedule/${id}/offer-letter`;
  const offerLetterAcceptUrl = (id) => `${baseApi()}/offer-letter/${id}/accept`;
  const offerLetterRejectUrl = (id) => `${baseApi()}/offer-letter/${id}/reject`;

  useEffect(() => { fetchOffers(); }, []);

  const fetchOffers = async () => {
    setLoading(true);
    setError("");

    console.log("============================================================");
    console.log("[StudentOffers] START fetchOffers");
    console.log("[StudentOffers] rest object:", rest);
    console.log("[StudentOffers] rest.jobApplications URL:", rest.jobApplications);
    console.log("[StudentOffers] baseApi():", baseApi());
    console.log("[StudentOffers] token (cookie):", Cookies.get("token"));
    console.log("[StudentOffers] token (localStorage):", localStorage.getItem("token"));
    console.log("============================================================");

    try {
      // ── STEP 1: Fetch all job applications ──────────────────────────────
      console.log("[StudentOffers] STEP 1 — fetching job applications");
      console.log("[StudentOffers] STEP 1 — URL:", rest.jobApplications);

      const appsRes = await axios.get(rest.jobApplications, getHeaders());

      console.log("[StudentOffers] STEP 1 — axios response status:", appsRes.status);
      console.log("[StudentOffers] STEP 1 — response.data:", appsRes.data);
      console.log("[StudentOffers] STEP 1 — response.data.data:", appsRes.data?.data);

      const apps = Array.isArray(appsRes.data?.data) ? appsRes.data.data
                 : Array.isArray(appsRes.data)        ? appsRes.data : [];

      console.log("[StudentOffers] STEP 1 — final apps array:", apps);
      console.log("[StudentOffers] STEP 1 — apps count:", apps.length);
      if (apps.length > 0) {
        console.log("[StudentOffers] STEP 1 — first app:", apps[0]);
        console.log("[StudentOffers] STEP 1 — app IDs:", apps.map((a) => a.jobApplicationId || a.id));
      } else {
        console.warn("[StudentOffers] STEP 1 — NO applications returned. Student may have no applications.");
      }

      // ── STEP 2: Fetch interviews per application ────────────────────────
      console.log("[StudentOffers] STEP 2 — fetching interviews for each application");

      const invArrays = await Promise.all(
        apps.map(async (app) => {
          const appId = app.jobApplicationId || app.id;
          const url   = `${baseApi()}/job-application/${appId}/interview`;
          console.log(`[StudentOffers] STEP 2 — app ${appId} URL:`, url);

          try {
            const res  = await axios.get(url, getHeaders());
            console.log(`[StudentOffers] STEP 2 — app ${appId} response status:`, res.status);
            console.log(`[StudentOffers] STEP 2 — app ${appId} response.data:`, res.data);
            console.log(`[StudentOffers] STEP 2 — app ${appId} response.data.data:`, res.data?.data);

            const data = res.data?.data || res.data;
            const list = Array.isArray(data) ? data : data ? [data] : [];

            console.log(`[StudentOffers] STEP 2 — app ${appId} parsed list (${list.length} items):`, list);
            list.forEach((i, idx) => {
              console.log(
                `[StudentOffers] STEP 2 — app ${appId} interview[${idx}]`,
                "| interviewId:", i.interviewId,
                "| status:", i.status,
                "| result:", i.result,
                "| full object:", i
              );
            });

            const selected = list.filter((i) => i.status === "Selected");
            console.log(`[StudentOffers] STEP 2 — app ${appId} selected (status==="Selected") count:`, selected.length);

            if (list.length > 0 && selected.length === 0) {
              console.warn(
                `[StudentOffers] STEP 2 — app ${appId} has interviews but none are Selected.`,
                "All statuses found:", list.map((i) => i.status)
              );
            }

            return selected.map((i) => ({ ...i, _app: app }));
          } catch (err) {
            console.error(
              `[StudentOffers] STEP 2 — app ${appId} FAILED`,
              "| HTTP status:", err.response?.status,
              "| response data:", err.response?.data,
              "| message:", err.message
            );
            return [];
          }
        })
      );

      const selected = invArrays.flat();
      console.log("[StudentOffers] STEP 2 — ALL selected interviews (flat):", selected);
      console.log("[StudentOffers] STEP 2 — total selected count:", selected.length);
      if (selected.length === 0) {
        console.warn("[StudentOffers] STEP 2 — No selected interviews. Student not yet marked Selected by company.");
      }

      setOffers(selected);

      // ── STEP 3: Fetch offer letter for each selected interview ──────────
      console.log("[StudentOffers] STEP 3 — fetching offer letters for selected interviews");
      await fetchAllOfferLetters(selected);

    } catch (err) {
      console.error("[StudentOffers] FATAL ERROR:", err);
      console.error("[StudentOffers] FATAL — HTTP status:", err.response?.status);
      console.error("[StudentOffers] FATAL — response data:", err.response?.data);
      console.error("[StudentOffers] FATAL — message:", err.message);
      setError("Failed to load offers. Please try again.");
    } finally {
      setLoading(false);
      console.log("[StudentOffers] fetchOffers complete");
      console.log("============================================================");
    }
  };

  const fetchAllOfferLetters = async (selectedOffers) => {
    console.log("[StudentOffers] STEP 3 — checking offer letters for", selectedOffers.length, "interview(s)");

    const results = await Promise.all(
      selectedOffers.map(async (offer) => {
        const interviewId = offer.interviewId || offer.id;
        const url         = offerLetterGetUrl(interviewId);
        console.log(`[StudentOffers] STEP 3 — interview ${interviewId} URL:`, url);

        try {
          const res  = await axios.get(url, getHeaders());
          console.log(`[StudentOffers] STEP 3 — interview ${interviewId} response status:`, res.status);
          console.log(`[StudentOffers] STEP 3 — interview ${interviewId} response.data:`, res.data);
          console.log(`[StudentOffers] STEP 3 — interview ${interviewId} response.data.data:`, res.data?.data);

          const data = res.data?.data || res.data;
          console.log(`[StudentOffers] STEP 3 — interview ${interviewId} parsed data:`, data);

          if (data && (data.offerLetterId || data.id)) {
            const mapped = {
              interviewId,
              offerLetterId: data.offerLetterId || data.id,
              status:        data.status        || "Pending",
              pdfBase64:     data.offerLetter   || data.offerLetterFile || null,
              date:          data.date          || null,
            };
            console.log(`[StudentOffers] STEP 3 — interview ${interviewId} OFFER FOUND:`, mapped);
            console.log(`[StudentOffers] STEP 3 — interview ${interviewId} PDF present:`, !!mapped.pdfBase64);
            return mapped;
          }

          console.log(`[StudentOffers] STEP 3 — interview ${interviewId} no offer letter yet`);
          return { interviewId, offerLetterId: null, status: null, pdfBase64: null };
        } catch (err) {
          console.warn(
            `[StudentOffers] STEP 3 — interview ${interviewId} FAILED (expected if offer not sent yet)`,
            "| HTTP status:", err.response?.status,
            "| data:", err.response?.data,
            "| message:", err.message
          );
          return { interviewId, offerLetterId: null, status: null, pdfBase64: null };
        }
      })
    );

    console.log("[StudentOffers] STEP 3 — all results:", results);
    const map = {};
    results.forEach((r) => { map[r.interviewId] = r; });
    console.log("[StudentOffers] STEP 3 — final offerLetterMap:", map);
    setOfferLetterMap(map);
  };

  const refetchSingleOffer = async (interviewId) => {
    console.log(`[StudentOffers] refetchSingleOffer — interviewId:`, interviewId);
    try {
      const res  = await axios.get(offerLetterGetUrl(interviewId), getHeaders());
      const data = res.data?.data || res.data;
      console.log(`[StudentOffers] refetchSingleOffer — data:`, data);
      if (data && (data.offerLetterId || data.id)) {
        setOfferLetterMap((prev) => ({
          ...prev,
          [interviewId]: {
            interviewId,
            offerLetterId: data.offerLetterId || data.id,
            status:        data.status        || "Pending",
            pdfBase64:     data.offerLetter   || data.offerLetterFile || null,
            date:          data.date          || null,
          },
        }));
      }
    } catch (err) {
      console.warn(`[StudentOffers] refetchSingleOffer FAILED:`, err.response?.status, err.message);
    }
  };

  const openOfferLetter = (pdfBase64, title = "Offer Letter") => {
    console.log("[StudentOffers] openOfferLetter — PDF present:", !!pdfBase64, "| title:", title);
    if (!pdfBase64) { alert("Offer letter PDF not available."); return; }
    const src = pdfBase64.startsWith("data:")
      ? pdfBase64.replace(/^data:[^;]+;base64,/, "data:application/pdf;base64,")
      : `data:application/pdf;base64,${pdfBase64}`;
    const win = window.open();
    if (win) {
      win.document.write(`<iframe src="${src}" style="width:100%;height:100vh;border:none;"></iframe>`);
      win.document.title = title;
    }
  };

  const handleAccept = async (interviewId, offerLetterId) => {
    console.log("[StudentOffers] handleAccept — interviewId:", interviewId, "| offerLetterId:", offerLetterId);
    console.log("[StudentOffers] handleAccept — URL:", offerLetterAcceptUrl(offerLetterId));
    setActionLoading((p) => ({ ...p, [offerLetterId]: true }));
    setActionMsg((p)     => ({ ...p, [offerLetterId]: { text: "", type: "" } }));
    try {
      const res = await axios.get(offerLetterAcceptUrl(offerLetterId), getHeaders());
      console.log("[StudentOffers] handleAccept — response:", res.data);
      await refetchSingleOffer(interviewId);
      setActionMsg((p) => ({ ...p, [offerLetterId]: { text: "Offer accepted successfully!", type: "success" } }));
    } catch (err) {
      console.error("[StudentOffers] handleAccept FAILED:", err.response?.status, err.response?.data, err.message);
      setActionMsg((p) => ({
        ...p,
        [offerLetterId]: { text: err.response?.data?.message || "Failed to accept offer.", type: "error" },
      }));
    } finally {
      setActionLoading((p) => ({ ...p, [offerLetterId]: false }));
    }
  };

  const handleReject = async (interviewId, offerLetterId) => {
    if (!window.confirm("Are you sure you want to reject this offer?")) return;
    console.log("[StudentOffers] handleReject — interviewId:", interviewId, "| offerLetterId:", offerLetterId);
    console.log("[StudentOffers] handleReject — URL:", offerLetterRejectUrl(offerLetterId));
    setActionLoading((p) => ({ ...p, [offerLetterId]: true }));
    setActionMsg((p)     => ({ ...p, [offerLetterId]: { text: "", type: "" } }));
    try {
      const res = await axios.get(offerLetterRejectUrl(offerLetterId), getHeaders());
      console.log("[StudentOffers] handleReject — response:", res.data);
      await refetchSingleOffer(interviewId);
      setActionMsg((p) => ({ ...p, [offerLetterId]: { text: "Offer rejected.", type: "error" } }));
    } catch (err) {
      console.error("[StudentOffers] handleReject FAILED:", err.response?.status, err.response?.data, err.message);
      setActionMsg((p) => ({
        ...p,
        [offerLetterId]: { text: err.response?.data?.message || "Failed to reject offer.", type: "error" },
      }));
    } finally {
      setActionLoading((p) => ({ ...p, [offerLetterId]: false }));
    }
  };

  // ── Helpers ──────────────────────────────────────────────────────────────
  const getApp         = (inv) => inv?.jobApplicationModel || inv?._app || {};
  const getSuggest     = (inv) => getApp(inv)?.jobSuggestionModel || {};
  const getJobPost     = (inv) => getSuggest(inv)?.jobPostModel    || {};
  const getResumeModel = (inv) => getApp(inv)?.resumeModel         || {};
  const getStudent     = (inv) => getResumeModel(inv)?.studentModel || getSuggest(inv)?.studentModel || {};
  const getName        = (inv) => getStudent(inv)?.name            || "Student";
  const getDept        = (inv) => getStudent(inv)?.departmentModel?.departmentName || "—";
  const getEmail       = (inv) => getStudent(inv)?.email           || "—";
  const getCompanyName = (inv) => getJobPost(inv)?.companyModel?.companyName || "Company";
  const getJobTitle    = (inv) => getJobPost(inv)?.tiitle || getJobPost(inv)?.title || "—";

  const formatDate = (d) => {
    if (!d) return "—";
    return new Date(d).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
  };

  const OFFER_STATUS_CFG = {
    Pending:  { label: "Awaiting Your Response", bg: "rgba(14,165,233,0.1)",  color: "#0ea5e9" },
    Accepted: { label: "Offer Accepted",          bg: "rgba(22,163,74,0.1)",   color: "#16a34a" },
    Rejected: { label: "Offer Rejected",          bg: "rgba(220,38,38,0.1)",   color: "#dc2626" },
  };

  return (
    <div className="p-4">
      <h2 className="fs-5 bold mb-1">My Offers</h2>
      <p className="fs-p9 text-secondary mb-4">Interviews where you were selected</p>

      {/* Stats */}
      <div className="row mb-4">
        {[
          { label: "Interviews Cleared", value: offers.length,                                                               color: "#16a34a" },
          { label: "Companies",          value: new Set(offers.map(getCompanyName)).size,                                    color: "#325563" },
          { label: "Offers Received",    value: Object.values(offerLetterMap).filter((o) => o.offerLetterId).length,         color: "#0ea5e9" },
          { label: "Offers Accepted",    value: Object.values(offerLetterMap).filter((o) => o.status === "Accepted").length, color: "#16a34a" },
        ].map((s, i) => (
          <div className="col-3 p-2" key={i}>
            <div className="card p-4 stat-card text-center">
              <h2 className="bold" style={{ color: s.color }}>{loading ? "..." : s.value}</h2>
              <p className="fs-p9 text-secondary">{s.label}</p>
            </div>
          </div>
        ))}
      </div>

      {loading ? (
        <div className="card p-5 text-center">
          <p className="text-secondary mt-2">Loading your offers...</p>
        </div>
      ) : error ? (
        <div className="card p-4" style={{ borderLeft: "4px solid var(--danger)" }}>
          <p style={{ color: "var(--danger)" }}>{error}</p>
          <button className="btn btn-primary mt-3 w-auto" style={{ padding: "8px 20px" }} onClick={fetchOffers}>
            Retry
          </button>
        </div>
      ) : offers.length === 0 ? (
        <div className="card p-5 text-center">
          <p className="bold mt-2">No offers yet</p>
          <p className="text-secondary fs-p9 mt-1">
            Offers appear here once you are marked as Selected in an interview.
          </p>
        </div>
      ) : (
        <>
          <div className="row space-between items-center mb-3">
            <h4 className="bold">Selected Interviews ({offers.length})</h4>
            <button onClick={fetchOffers} style={{
              padding: "8px 16px", borderRadius: 8, border: "1px solid var(--border-color)",
              background: "#fff", cursor: "pointer", fontSize: "0.85rem", fontWeight: 600,
            }}>Refresh</button>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(340px, 1fr))", gap: 16 }}>
            {offers.map((offer, idx) => {
              const interviewId = offer.interviewId || offer.id || idx;
              const olData      = offerLetterMap[interviewId];
              const olStatus    = olData?.status        || null;
              const olId        = olData?.offerLetterId || null;
              const olPdf       = olData?.pdfBase64     || null;
              const olSent      = !!(olId);
              const statusCfg   = OFFER_STATUS_CFG[olStatus] || null;
              const isActing    = actionLoading[olId];
              const msg         = actionMsg[olId];

              return (
                <div key={interviewId} className="card p-4" style={{ borderTop: "4px solid #16a34a" }}>

                  {/* Header */}
                  <div className="row space-between items-center mb-3">
                    <div>
                      <h4 className="bold">{getCompanyName(offer)}</h4>
                      <p className="fs-p9 text-secondary">{getJobTitle(offer)}</p>
                    </div>
                    <span style={{
                      fontSize: "0.7rem", fontWeight: 700, padding: "4px 10px", borderRadius: 10,
                      background: "rgba(22,163,74,0.1)", color: "#16a34a",
                    }}>Selected</span>
                  </div>

                  {/* Student info */}
                  <div style={{ marginBottom: 14 }}>
                    <p className="fs-p9 bold">{getName(offer)}</p>
                    <p className="fs-p8 text-secondary">{getDept(offer)} — {getEmail(offer)}</p>
                  </div>

                  {/* Interview info */}
                  <div style={{ display: "flex", gap: 20, marginBottom: 14 }}>
                    <div>
                      <p className="fs-p8 text-secondary">Interview Date</p>
                      <p className="bold fs-p9">{formatDate(offer.interviewDateTime || offer.interviewDate)}</p>
                    </div>
                    <div>
                      <p className="fs-p8 text-secondary">Mode</p>
                      <p className="bold fs-p9">{offer.interviewMode || offer.mode || "—"}</p>
                    </div>
                  </div>

                  {/* Notice */}
                  <div style={{
                    background: "rgba(22,163,74,0.07)", border: "1px solid rgba(22,163,74,0.2)",
                    borderRadius: 8, padding: "10px 12px", marginBottom: 14,
                  }}>
                    <p className="fs-p9 bold" style={{ color: "#16a34a" }}>
                      Congratulations! You have been selected by {getCompanyName(offer)}.
                    </p>
                    <p className="fs-p8 text-secondary mt-1">
                      {olSent
                        ? "The company has sent you an offer letter below."
                        : "Awaiting the official offer letter from the company."}
                    </p>
                  </div>

                  {/* Offer Letter Section */}
                  {olSent ? (
                    <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>

                      {statusCfg && (
                        <div style={{
                          padding: "8px 12px", borderRadius: 8,
                          background: statusCfg.bg, border: `1px solid ${statusCfg.color}40`,
                        }}>
                          <span style={{ fontSize: "0.78rem", fontWeight: 600, color: statusCfg.color }}>
                            {statusCfg.label}
                          </span>
                        </div>
                      )}

                      {olPdf ? (
                        <button
                          onClick={() => openOfferLetter(olPdf, `Offer Letter - ${getCompanyName(offer)}`)}
                          style={{
                            display: "flex", alignItems: "center", gap: 10,
                            padding: "10px 14px", background: "var(--gray-100)",
                            borderRadius: 8, cursor: "pointer", width: "100%",
                            border: "1px solid rgba(50,85,99,0.2)", textAlign: "left",
                          }}
                        >
                          <div style={{
                            width: 32, height: 32, borderRadius: 6, background: "#325563",
                            color: "#fff", display: "flex", alignItems: "center",
                            justifyContent: "center", fontSize: "0.6rem", fontWeight: 700, flexShrink: 0,
                          }}>PDF</div>
                          <div>
                            <p className="bold fs-p8" style={{ color: "#325563" }}>View Offer Letter</p>
                            <p className="fs-p8 text-secondary">Click to open</p>
                          </div>
                        </button>
                      ) : (
                        <p className="fs-p8 text-secondary">Offer letter PDF not available yet.</p>
                      )}

                      {msg?.text && (
                        <div style={{
                          padding: "8px 12px", borderRadius: 8, fontSize: "0.82rem",
                          background: msg.type === "success" ? "rgba(22,163,74,0.08)" : "rgba(220,38,38,0.08)",
                          border: `1px solid ${msg.type === "success" ? "rgba(22,163,74,0.3)" : "rgba(220,38,38,0.3)"}`,
                          color: msg.type === "success" ? "#16a34a" : "#dc2626",
                        }}>
                          {msg.text}
                        </div>
                      )}

                      {olStatus === "Pending" && olId && (
                        <div style={{ display: "flex", gap: 8 }}>
                          <button
                            onClick={() => handleAccept(interviewId, olId)}
                            disabled={isActing}
                            style={{
                              flex: 1, padding: "9px", borderRadius: 8,
                              fontSize: "0.85rem", fontWeight: 600,
                              background: isActing ? "var(--gray-400)" : "#16a34a",
                              color: "#fff", border: "none",
                              cursor: isActing ? "not-allowed" : "pointer",
                            }}
                          >
                            {isActing ? "Processing..." : "Accept Offer"}
                          </button>
                          <button
                            onClick={() => handleReject(interviewId, olId)}
                            disabled={isActing}
                            style={{
                              flex: 1, padding: "9px", borderRadius: 8,
                              fontSize: "0.85rem", fontWeight: 600, background: "#fff",
                              color: isActing ? "var(--gray-400)" : "#dc2626",
                              border: `1px solid ${isActing ? "var(--gray-400)" : "#dc2626"}`,
                              cursor: isActing ? "not-allowed" : "pointer",
                            }}
                          >
                            Reject
                          </button>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div style={{
                      padding: "10px 14px", borderRadius: 8,
                      background: "rgba(107,114,128,0.06)",
                      border: "1px solid rgba(107,114,128,0.2)",
                    }}>
                      <p className="fs-p9" style={{ color: "#6b7280", fontWeight: 600 }}>
                        Offer letter not sent yet
                      </p>
                      <p className="fs-p8 text-secondary mt-1">
                        The company will send you an official offer letter soon.
                      </p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </>
      )}
    </div>
  );
}

export default StudentOffers;