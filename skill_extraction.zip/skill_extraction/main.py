from flask import Flask, request, jsonify
from flask_cors import CORS
import pdfplumber
from docx import Document
from openai import OpenAI
import json
import os
import re
from dotenv import load_dotenv
load_dotenv()
API_KEY = os.getenv("OPENAI_API_KEY")
if API_KEY:
    print('found api key')
else:
    print('No api key found')

client = OpenAI(api_key=API_KEY)
def pdf_to_text(file_path):
    text = ""
    with pdfplumber.open(file_path) as pdf:
        for page in pdf.pages:
            text += page.extract_text() + "\n"
    return text

def docx_to_text(file_path):
    print(file_path)
    doc = Document(file_path)
    return "\n".join([para.text for para in doc.paragraphs])

def extract_text(file_path):
    if file_path.endswith(".pdf"):
        return pdf_to_text(file_path)
    elif file_path.endswith(".docx"):
        return docx_to_text(file_path)
    else:
        raise ValueError("Unsupported file format")

def extract_skills(text):
    response = client.responses.create(
        model="gpt-4.1-mini",
        input=f"""
Extract skills from the text below.

Return ONLY JSON:
{{
  "technical_skills": [],
  "soft_skills": []
}}

Text:
{text}
"""
    )

    # safer extraction
    raw_output = response.output[0].content[0].text.strip()

    # print("\n RAW OUTPUT:\n", raw_output)

    # extract JSON
    match = re.search(r"\{.*\}", raw_output, re.DOTALL)

    if not match:
        print("No JSON found")
        return {"technical_skills": [], "soft_skills": []}

    try:
        return json.loads(match.group())
    except json.JSONDecodeError:
        print(" JSON decode failed")
        return {"technical_skills": [], "soft_skills": []}



def calculate_match(resume_list, job_list):
    if not job_list:
        return {
            "match_percentage": None,
            "matched": [],
            "missing": [],
            "note": "No skills provided in job description"
        }

    resume_set = set(s.lower() for s in resume_list)
    job_set = set(s.lower() for s in job_list)

    matched = resume_set & job_set
    missing = job_set - resume_set

    percentage = (len(matched) / len(job_set)) * 100

    return {
        "match_percentage": round(percentage, 2),
        "matched": sorted(matched),
        "missing": sorted(missing)
    }



def match_skills(resume, job):
    tech_result = calculate_match(
        resume.get("technical_skills", []),
        job.get("technical_skills", [])
    )

    soft_result = calculate_match(
        resume.get("soft_skills", []),
        job.get("soft_skills", [])
    )

    return {
        "technical_skills": tech_result,
        "soft_skills": soft_result
    }

app = Flask(__name__)
CORS(app)
UPLOAD_FOLDER = 'static/resumes'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
@app.route("/placement-prediction", methods=['POST'])
def placement_prediction():
    if 'file' not in request.files:
        return jsonify({"error": "No file part"}), 400
    file = request.files['file']

    if file.filename == '':
        return jsonify({"error": "No selected file"}), 400

    # Save file
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
    file.save(file_path)
    job_description = request.form.get('job_description')
    file_url = BASE_DIR+"\\static\\resumes\\"+file.filename
    resume_text = extract_text(file_url)
    resume_skills = extract_skills(resume_text)
    job_skills = extract_skills(job_description)
    result = match_skills(resume_skills, job_skills)
    return result

app.run(debug=True, port=8081)



