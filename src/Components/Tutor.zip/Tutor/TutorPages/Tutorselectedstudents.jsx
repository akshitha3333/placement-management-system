import { useState, useEffect } from "react";
import axios from "axios";
import Cookies from "js-cookie";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import L from "leaflet";
const rest = require("../../../Rest");

// Fix leaflet default marker icons
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
  iconUrl:       "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  shadowUrl:     "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
});

const baseJob = rest.jobApplications.replace("/job-applications", "");

const getHeaders = () => ({
  headers: {
    "Content-Type": "application/json",
    Authorization: `Bearer ${Cookies.get("token") || ""}`,
  },
});

const formatDate = (d) => {
  if (!d) return "—";
  try { return new Date(d).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" }); }
  catch { return d; }
};

function TutorSelectedStudents() {
  const [rows,    setRows]    = useState([]); // placed students with full details
  const [loading, setLoading] = useState(true);
  const [error,   setError]   = useState("");
  const [selected, setSelected] = useState(null); // selected row for detail panel
  const [view,    setView]    = useState("list"); // "list" | "map"

  useEffect(() => { fetchAll(); }, []);

  const fetchAll = async () => {
    setLoading(true);
    setError("");
    try {
      // Step 1: all applications for this tutor's suggestions
      const appsRes = await axios.get(rest.jobApplications, getHeaders());
      const apps    = Array.isArray(appsRes.data?.data) ? appsRes.data.data
                    : Array.isArray(appsRes.data)        ? appsRes.data : [];
      console.log("STEP 1 — Applications:", apps.length, apps);

      // Step 2: interviews per app — keep only Selected / OFFER_SENT
      const invArrays = await Promise.all(
        apps.map(async (app) => {
          const appId = app.jobApplicationId || app.id;
          try {
            const res  = await axios.get(`${baseJob}/job-application/${appId}/interview`, getHeaders());
            const data = res.data?.data || res.data;
            const list = Array.isArray(data) ? data : data ? [data] : [];
            return list
              .filter((i) => i.status === "Selected" || i.status === "OFFER_SENT")
              .map((i) => ({ ...i, _app: app }));
          } catch { return []; }
        })
      );
      const selectedInvs = invArrays.flat();
      console.log("STEP 2 — Selected interviews:", selectedInvs.length, selectedInvs);

      // Step 3: offer letter per interview — keep only Accepted
      const placedRows = [];
      await Promise.all(
        selectedInvs.map(async (inv) => {
          const interviewId = inv.interviewId || inv.id;
          try {
            const res  = await axios.get(`${baseJob}/interview-schedule/${interviewId}/offer-letter`, getHeaders());
            const data = res.data?.data || res.data;
            console.log(`STEP 3 — Offer for interview ${interviewId}:`, data);

            if (data && data.status === "Accepted") {
              // Extract nested objects
              const app      = inv._app || inv.jobApplicationModel || {};
              const suggest  = app.jobSuggestionModel || {};
              const jobPost  = suggest.jobPostModel   || {};
              const company  = jobPost.companyModel   || {};
              const resume   = app.resumeModel        || {};
              const student  = resume.studentModel    || suggest.studentModel || {};

              placedRows.push({
                interviewId,
                inv,
                offer: data,
                // Student
                studentName:  student.name                            || "—",
                studentEmail: student.email                           || "—",
                studentPhone: student.phone                           || "—",
                rollNo:       student.rollNumber                      || "—",
                percentage:   student.percentage                      || "—",
                department:   student.departmentModel?.departmentName || "—",
                year:         student.year                            || "—",
                // Job
                jobTitle:     jobPost.tiitle || jobPost.title         || "—",
                // Company
                companyName:  company.companyName                     || "—",
                companyEmail: company.email                           || "—",
                industry:     company.industryType                    || "—",
                location:     company.location                        || "—",
                website:      company.website                         || "—",
                latitude:     company.latitude                        || null,
                longitude:    company.longitude                       || null,
                // Offer
                offerDate:    data.date                               || null,
                offerLetterId: data.offerLetterId || data.id          || null,
              });
            }
          } catch { /* no offer or not accepted */ }
        })
      );

      console.log("STEP 4 — Placed students:", placedRows.length, placedRows);
      setRows(placedRows);
      if (placedRows.length > 0) setSelected(placedRows[0]);
    } catch (err) {
      console.error("fetchAll error:", err.response?.data || err.message);
      setError("Failed to load data. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  // Map markers — only rows that have valid coordinates
  const mapRows = rows.filter(
    (r) => r.latitude && r.longitude &&
           !isNaN(parseFloat(r.latitude)) && !isNaN(parseFloat(r.longitude))
  );
  const mapCenter = mapRows.length > 0
    ? [parseFloat(mapRows[0].latitude), parseFloat(mapRows[0].longitude)]
    : [20.5937, 78.9629];

  if (loading) {
    return <div className="p-4"><p className="text-secondary">Loading placed students...</p></div>;
  }

  return (
    <div className="p-4" style={{ height: "calc(100vh - 70px)", overflowY: "auto" }}>

      {/* Header */}
      <div className="row space-between items-center mb-4">
        <div>
          <h2 className="fs-5 bold mb-1">Placed Students</h2>
          <p className="fs-p9 text-secondary">
            Students from your department who accepted an offer letter
          </p>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          {/* View toggle */}
          <div style={{ display: "flex", border: "1px solid var(--border-color)", borderRadius: 8, overflow: "hidden" }}>
            {["list", "map"].map((v) => (
              <button
                key={v}
                onClick={() => setView(v)}
                style={{
                  padding: "7px 18px", border: "none", cursor: "pointer",
                  fontWeight: 600, fontSize: "0.82rem",
                  background: view === v ? "var(--primary)" : "#fff",
                  color:      view === v ? "#fff"           : "var(--text-secondary)",
                }}
              >
                {v === "list" ? "List" : "Map"}
              </button>
            ))}
          </div>
          <button
            onClick={fetchAll}
            style={{
              padding: "7px 16px", borderRadius: 8,
              border: "1px solid var(--border-color)",
              background: "#fff", cursor: "pointer",
              fontSize: "0.82rem", fontWeight: 600,
            }}
          >
            Refresh
          </button>
        </div>
      </div>

      {error && (
        <div className="alert-danger mb-4">
          <p className="text-danger fs-p9">{error}</p>
        </div>
      )}

      {/* Stat */}
      <div className="row mb-4" style={{ gap: 10 }}>
        {[
          { label: "Placed Students",   value: rows.length,    color: "var(--success)"  },
          { label: "Companies",         value: new Set(rows.map((r) => r.companyName)).size, color: "#0ea5e9" },
          { label: "With Map Location", value: mapRows.length, color: "var(--warning)"  },
        ].map((s, i) => (
          <div key={i} style={{ flex: "0 0 160px" }}>
            <div className="card p-3 text-center stat-card">
              <h2 className="bold" style={{ color: s.color }}>{s.value}</h2>
              <p className="fs-p9 text-secondary">{s.label}</p>
            </div>
          </div>
        ))}
      </div>

      {rows.length === 0 ? (
        <div className="card p-5 text-center">
          <p className="bold mb-1">No placed students yet</p>
          <p className="fs-p9 text-secondary mt-1">
            Students will appear here once they accept an offer letter from a company.
          </p>
        </div>

      ) : view === "map" ? (
        /* ══════════════════════════════════════════════
           MAP VIEW
        ══════════════════════════════════════════════ */
        <div>
          {mapRows.length === 0 && (
            <div className="alert-info mb-3">
              <p className="fs-p9" style={{ color: "var(--info)" }}>
                No company locations set. Ask companies to add coordinates in their profile.
              </p>
            </div>
          )}

          <div style={{ height: 420, borderRadius: 12, overflow: "hidden", border: "1px solid var(--border-color)", marginBottom: 20 }}>
            <MapContainer
              center={mapCenter}
              zoom={mapRows.length > 0 ? 6 : 5}
              style={{ height: "100%", width: "100%" }}
              scrollWheelZoom={true}
            >
              <TileLayer
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              />
              {mapRows.map((r, i) => (
                <Marker
                  key={r.interviewId || i}
                  position={[parseFloat(r.latitude), parseFloat(r.longitude)]}
                >
                  <Popup>
                    <div style={{ minWidth: 180 }}>
                      <p style={{ fontWeight: 700, marginBottom: 4 }}>{r.studentName}</p>
                      <p style={{ fontSize: "0.78rem", color: "#555", marginBottom: 2 }}>
                        {r.department} · {r.rollNo}
                      </p>
                      <p style={{ fontSize: "0.78rem", color: "#555", marginBottom: 2 }}>
                        {r.companyName}
                      </p>
                      <p style={{ fontSize: "0.78rem", color: "#555", marginBottom: 2 }}>
                        {r.jobTitle}
                      </p>
                      <p style={{ fontSize: "0.72rem", color: "#16a34a", fontWeight: 600 }}>
                        Accepted: {formatDate(r.offerDate)}
                      </p>
                      {r.location && (
                        <p style={{ fontSize: "0.72rem", color: "#888", marginTop: 2 }}>
                          {r.location}
                        </p>
                      )}
                    </div>
                  </Popup>
                </Marker>
              ))}
            </MapContainer>
          </div>

          {/* Legend below map */}
          <div style={{ display: "flex", flexWrap: "wrap", gap: 10 }}>
            {mapRows.map((r, i) => (
              <div key={i} style={{
                padding: "8px 14px", borderRadius: 8,
                border: "1px solid var(--border-color)",
                background: "#fff", fontSize: "0.8rem",
              }}>
                <span style={{ fontWeight: 700 }}>{r.studentName}</span>
                <span className="text-secondary"> · {r.companyName} · {r.location}</span>
              </div>
            ))}
          </div>
        </div>

      ) : (
        /* ══════════════════════════════════════════════
           LIST VIEW — two-panel layout
        ══════════════════════════════════════════════ */
        <div className="row" style={{ gap: 14, alignItems: "flex-start" }}>

          {/* Left — student list */}
          <div style={{ flex: 1 }}>
            <div className="card p-0" style={{ overflow: "hidden" }}>
              {rows.map((r, idx) => {
                const isActive = selected?.interviewId === r.interviewId;
                return (
                  <div
                    key={r.interviewId || idx}
                    onClick={() => setSelected(r)}
                    style={{
                      padding: "14px 16px",
                      borderBottom: "1px solid var(--border-color)",
                      borderLeft: isActive ? "4px solid var(--success)" : "4px solid transparent",
                      background: isActive ? "rgba(22,163,74,0.04)" : "#fff",
                      cursor: "pointer",
                      transition: "background 0.12s",
                    }}
                  >
                    <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                      <div style={{
                        width: 38, height: 38, borderRadius: "50%", flexShrink: 0,
                        background: isActive ? "var(--success)" : "var(--primary)",
                        color: "#fff",
                        display: "flex", alignItems: "center", justifyContent: "center",
                        fontWeight: 700, fontSize: "0.9rem",
                      }}>
                        {(r.studentName || "S").charAt(0).toUpperCase()}
                      </div>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <p className="bold fs-p9">{r.studentName}</p>
                        <p className="fs-p8 text-secondary">
                          {r.department} · {r.rollNo}
                        </p>
                        <p className="fs-p8" style={{ color: "var(--success)", fontWeight: 600, marginTop: 2 }}>
                          {r.companyName}
                        </p>
                      </div>
                      <span style={{
                        fontSize: "0.7rem", fontWeight: 600, padding: "3px 8px", borderRadius: 10,
                        background: "rgba(22,163,74,0.1)", color: "var(--success)", flexShrink: 0,
                      }}>
                        Placed
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right — detail panel */}
          <div style={{ flex: 2 }}>
            {selected ? (
              <div>

                {/* Student info card */}
                <div className="card p-4 mb-3" style={{ borderLeft: "4px solid var(--success)" }}>
                  <div className="row space-between items-center mb-3">
                    <h4 className="bold">Student Details</h4>
                    <span style={{
                      fontSize: "0.75rem", fontWeight: 600, padding: "4px 12px", borderRadius: 10,
                      background: "rgba(22,163,74,0.1)", color: "var(--success)",
                    }}>
                      Placed
                    </span>
                  </div>

                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 14 }}>
                    {[
                      { label: "Name",       value: selected.studentName  },
                      { label: "Email",      value: selected.studentEmail },
                      { label: "Phone",      value: selected.studentPhone },
                      { label: "Roll No",    value: selected.rollNo       },
                      { label: "Percentage", value: `${selected.percentage}%` },
                      { label: "Department", value: selected.department   },
                      { label: "Year",       value: selected.year         },
                    ].map((f) => (
                      <div key={f.label} style={{ background: "var(--gray-100)", borderRadius: 8, padding: "8px 12px" }}>
                        <p className="fs-p8 text-secondary">{f.label}</p>
                        <p className="bold fs-p9">{f.value || "—"}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Offer + Company card */}
                <div className="card p-4 mb-3">
                  <h4 className="bold mb-3">Placement Details</h4>

                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 14 }}>
                    {[
                      { label: "Job Title",        value: selected.jobTitle    },
                      { label: "Company",          value: selected.companyName },
                      { label: "Industry",         value: selected.industry    },
                      { label: "Location",         value: selected.location    },
                      { label: "Company Email",    value: selected.companyEmail},
                      { label: "Website",          value: selected.website     },
                      { label: "Offer Accepted On",value: formatDate(selected.offerDate) },
                    ].map((f) => (
                      <div key={f.label} style={{ background: "var(--gray-100)", borderRadius: 8, padding: "8px 12px" }}>
                        <p className="fs-p8 text-secondary">{f.label}</p>
                        <p className="bold fs-p9">{f.value || "—"}</p>
                      </div>
                    ))}
                  </div>

                  {/* Google Maps link */}
                  {selected.latitude && selected.longitude && (
                    <a
                      href={`https://www.google.com/maps?q=${selected.latitude},${selected.longitude}`}
                      target="_blank"
                      rel="noreferrer"
                      style={{
                        display: "inline-block", padding: "7px 16px",
                        borderRadius: 8, fontSize: "0.82rem", fontWeight: 600,
                        background: "#0ea5e9", color: "#fff",
                        textDecoration: "none", marginBottom: 14,
                      }}
                    >
                      Open in Google Maps
                    </a>
                  )}
                </div>

                {/* Mini map for this student's company */}
                <div className="card p-4">
                  <h4 className="bold mb-3">Company Location</h4>
                  {selected.latitude && selected.longitude &&
                   !isNaN(parseFloat(selected.latitude)) &&
                   !isNaN(parseFloat(selected.longitude)) ? (
                    <>
                      <div style={{ height: 220, borderRadius: 10, overflow: "hidden", border: "1px solid var(--border-color)" }}>
                        <MapContainer
                          key={`${selected.latitude}-${selected.longitude}`}
                          center={[parseFloat(selected.latitude), parseFloat(selected.longitude)]}
                          zoom={14}
                          style={{ height: "100%", width: "100%" }}
                          scrollWheelZoom={false}
                          zoomControl={true}
                        >
                          <TileLayer
                            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                          />
                          <Marker position={[parseFloat(selected.latitude), parseFloat(selected.longitude)]}>
                            <Popup>
                              <p style={{ fontWeight: 700 }}>{selected.companyName}</p>
                              <p style={{ fontSize: "0.78rem" }}>{selected.location}</p>
                              <p style={{ fontSize: "0.78rem", color: "#16a34a" }}>
                                {selected.studentName} placed here
                              </p>
                            </Popup>
                          </Marker>
                        </MapContainer>
                      </div>
                      <p className="fs-p8 text-secondary mt-2">
                        {parseFloat(selected.latitude).toFixed(5)}, {parseFloat(selected.longitude).toFixed(5)}
                      </p>
                    </>
                  ) : (
                    <div style={{
                      height: 120, borderRadius: 10,
                      border: "1px solid var(--border-color)",
                      background: "var(--gray-100)",
                      display: "flex", alignItems: "center", justifyContent: "center",
                    }}>
                      <p className="fs-p9 text-secondary">
                        No map coordinates set for this company.
                      </p>
                    </div>
                  )}
                </div>

              </div>
            ) : (
              <div className="card p-5 text-center">
                <p className="fs-p9 text-secondary">Select a student from the list to view details.</p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

export default TutorSelectedStudents;